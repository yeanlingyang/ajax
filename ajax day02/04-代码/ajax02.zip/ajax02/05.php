<?php

  echo 'hello get';

?>