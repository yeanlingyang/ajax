<?php

  echo $_POST['username'] . $_POST['password'];

?>